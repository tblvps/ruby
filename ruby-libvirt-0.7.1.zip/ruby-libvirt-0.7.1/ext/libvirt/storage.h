#ifndef STORAGE_H
#define STORAGE_H

void ruby_libvirt_storage_init(void);

#endif
